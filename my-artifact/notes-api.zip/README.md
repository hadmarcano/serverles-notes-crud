# Get starting

- Before execute "serverless deploy" by command line, you must comment the "getNotes" function in our "serverless.yml" file, save this change and then run command "serverless deploy" in the command line.

- After run the command "serverless deploy" succesfully, uncomment the "getNotes" function, save and execute the command "serverless deploy" again.
